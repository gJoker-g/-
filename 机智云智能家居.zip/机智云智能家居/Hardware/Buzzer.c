#include "buzzer.h"
#include "Delay.h"
u8 Buzzer_Flag;

void Buzzer_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = Buzzer;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(Buzzer_PROT, &GPIO_InitStructure);
	GPIO_SetBits(Buzzer_PROT, Buzzer);
}

void Buzzer_ON(void)
{
	Buzzer_Flag = 1;
	GPIO_ResetBits(Buzzer_PROT, Buzzer);

}

void Buzzer_OFF(void)
{
	Buzzer_Flag = 0;
	GPIO_SetBits(Buzzer_PROT, Buzzer);	

}
void Buzzer_three_times(void) 
{
    for(uint8_t i=0; i<3; i++) 
	 {
        GPIO_ResetBits(Buzzer_PROT, Buzzer);  // 500ms�죬300ms���
		    Delay_ms(200);
		    GPIO_SetBits(Buzzer_PROT, Buzzer);
        if(i == 2)  break;                     // ���һ�β��ȴ����
    }
}













































































